#include <iostream>
#include <random>

int main() {
    // Initialisatie. Gebruik slechts één engine in je programma!
    std::random_device device;
    std::default_random_engine engine {device()};

    // Een paar random integers
    std::uniform_int_distribution<int> dist {1, 6}; // dobbelsteen
    for (int i = 0; i < 20; ++i) {
        std::cout << dist(engine) << ' ';
    }
    std::cout << '\n';
}
