#include "mylib.hpp"

mylib::myclass::myclass(const std::string& message) : _message {message} {}
