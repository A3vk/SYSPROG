#include <iostream>
#include <libmylib.hpp>

int main() {
    mylib::myclass obj {"Hello, world!"};
    std::cout << obj.message() << '\n';
}
